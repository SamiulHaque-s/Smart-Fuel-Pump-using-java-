import java.util.ArrayList;


// ================= BOOKING MANAGER =================

class BookingManager {

    ArrayList<Vehicle> bookings = new ArrayList<>();


    // Maximum 15 vehicles একটি pump-এর queue-তে থাকবে।

    static final int MAX_QUEUE = 15;


    // ================= COUNT QUEUE =================

    int queueCount(Pump pump) {

        int count = 0;

        for (Vehicle v : bookings) {

            if (v.pump.equalsIgnoreCase(
                    pump.getName())) {

                count++;
            }
        }

        return count;
    }


    // ================= BOOK FUEL =================

    boolean bookFuel(String vehicleNumber,
                     String fuel,
                     Pump pump) {

        int currentQueue = queueCount(pump);


        // Queue full হলে নতুন booking নেওয়া যাবে না।

        if (currentQueue >= MAX_QUEUE) {

            return false;
        }


        // Queue number 1 থেকে শুরু হবে।

        int queueNumber = currentQueue + 1;


        // Simple estimated time।

        int minute = 20 + currentQueue * 10;

        String time =
                "5:" + String.format("%02d", minute);


        bookings.add(
                new Vehicle(
                        vehicleNumber,
                        fuel,
                        pump.getName(),
                        time,
                        queueNumber
                )
        );


        return true;
    }


    // ================= CANCEL BOOKING =================

    boolean cancelBooking(String vehicleNumber) {

        for (int i = 0;
             i < bookings.size();
             i++) {

            if (bookings.get(i).number
                    .equalsIgnoreCase(vehicleNumber)) {

                bookings.remove(i);

                return true;
            }
        }

        return false;
    }


    // ================= GET BOOKINGS =================

    ArrayList<Vehicle> getBookings() {

        return bookings;
    }
}