// ================= FEEDBACK CLASS =================

class Feedback {

    String pump;
    int rating;
    String message;


    // ================= CONSTRUCTOR =================

    Feedback(String pump, int rating, String message) {

        this.pump = pump;
        this.rating = rating;
        this.message = message;
    }
}

