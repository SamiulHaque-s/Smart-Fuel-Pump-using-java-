// ================= ABSTRACT CLASS =================
// Abstract class সাধারণ class-এর মতো object তৈরি করার জন্য নয়।
// এখানে আমরা common idea/structure রাখি।

abstract class FuelStation {

    // abstract method এর body এখানে নেই।
    // Child class-কে এই method নিজের মতো করে লিখতে হবে।
    abstract void showInfo();
}
