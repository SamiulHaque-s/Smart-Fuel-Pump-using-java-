import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;


// ================= GUI CLASS =================

class GUI extends JFrame {

    // ================= MANAGERS =================

    PumpManager pumpManager =
            new PumpManager();

    BookingManager bookingManager =
            new BookingManager();


    ArrayList<Feedback> feedbacks =
            new ArrayList<>();


    // ================= GUI VARIABLES =================

    JPanel mainPanel;

    CardLayout cardLayout;


    // ================= COLORS =================

    Color dark =
            new Color(25, 35, 50);

    Color blue =
            new Color(35, 100, 180);

    Color light =
            new Color(245, 247, 250);


    // ================= CONSTRUCTOR =================

    GUI() {

        setTitle(
                "Smart Fuel Pump Management System"
        );

        setSize(1100, 650);

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setLocationRelativeTo(null);


        cardLayout = new CardLayout();

        mainPanel =
                new JPanel(cardLayout);


        // সব panel একই জায়গায় রাখা হচ্ছে।

        mainPanel.add(
                homePanel(),
                "HOME"
        );

        mainPanel.add(
                userPanel(),
                "USER"
        );

        mainPanel.add(
                adminPanel(),
                "ADMIN"
        );


        add(mainPanel);


        cardLayout.show(
                mainPanel,
                "HOME"
        );
    }


    // =====================================================
    // HOME PANEL
    // =====================================================

    JPanel homePanel() {

        JPanel panel =
                new JPanel(new BorderLayout());

        panel.setBackground(light);


        JLabel title =
                new JLabel(
                        "SMART FUEL PUMP MANAGEMENT SYSTEM",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );


        JPanel buttons =
                new JPanel(
                        new GridLayout(
                                4, 1, 15, 15
                        )
                );

        buttons.setBackground(light);

        buttons.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        350,
                        80,
                        350
                )
        );


        JButton user =
                button("User Panel");

        JButton admin =
                button("Admin Panel");

        JButton about =
                button("About Project");

        JButton exit =
                button("Exit");


        buttons.add(user);
        buttons.add(admin);
        buttons.add(about);
        buttons.add(exit);


        // User button চাপলে USER panel দেখাবে।

        user.addActionListener(
                e -> cardLayout.show(
                        mainPanel,
                        "USER"
                )
        );


        // Admin button চাপলে ADMIN panel।

        admin.addActionListener(
                e -> cardLayout.show(
                        mainPanel,
                        "ADMIN"
                )
        );


        about.addActionListener(
                e -> aboutProject()
        );


        exit.addActionListener(
                e -> System.exit(0)
        );


        panel.add(
                title,
                BorderLayout.NORTH
        );

        panel.add(
                buttons,
                BorderLayout.CENTER
        );


        return panel;
    }


    // =====================================================
    // USER PANEL
    // =====================================================

    JPanel userPanel() {

        JPanel panel =
                new JPanel(new BorderLayout());


        JPanel side =
                new JPanel(
                        new GridLayout(
                                12, 1, 5, 5
                        )
                );


        side.setBackground(dark);


        String[] names = {

                "Select Zone",
                "Search Pump",
                "Open Pumps",
                "All Pumps",
                "Queue Status",
                "Book Fuel",
                "My Bookings",
                "Cancel Booking",
                "Nearest Pump",
                "Sales History",
                "Rate Service"
        };


        for (String name : names) {

            JButton b =
                    sideButton(name);

            side.add(b);


            if (name.equals("Select Zone")) {

                b.addActionListener(
                        e -> selectZone()
                );

            } else if (name.equals("Search Pump")) {

                b.addActionListener(
                        e -> searchPump()
                );

            } else if (name.equals("Open Pumps")) {

                b.addActionListener(
                        e -> showOpenPumps()
                );

            } else if (name.equals("All Pumps")) {

                b.addActionListener(
                        e -> showAllPumps()
                );

            } else if (name.equals("Queue Status")) {

                b.addActionListener(
                        e -> queueStatus()
                );

            } else if (name.equals("Book Fuel")) {

                b.addActionListener(
                        e -> bookFuel()
                );

            } else if (name.equals("My Bookings")) {

                b.addActionListener(
                        e -> showBookings()
                );

            } else if (name.equals("Cancel Booking")) {

                b.addActionListener(
                        e -> cancelBooking()
                );

            } else if (name.equals("Nearest Pump")) {

                b.addActionListener(
                        e -> nearestPump()
                );

            } else if (name.equals("Sales History")) {

                b.addActionListener(
                        e -> salesHistory()
                );

            } else if (name.equals("Rate Service")) {

                b.addActionListener(
                        e -> rateService()
                );
            }
        }


        JButton back =
                sideButton("Back to Home");

        side.add(back);


        back.addActionListener(
                e -> cardLayout.show(
                        mainPanel,
                        "HOME"
                )
        );


        JLabel title =
                new JLabel("USER DASHBOARD");

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );


        panel.add(
                side,
                BorderLayout.WEST
        );

        panel.add(
                title,
                BorderLayout.NORTH
        );


        return panel;
    }


    // =====================================================
    // ADMIN PANEL
    // =====================================================

    JPanel adminPanel() {

        JPanel panel =
                new JPanel(new BorderLayout());


        JPanel side =
                new JPanel(
                        new GridLayout(
                                8, 1, 5, 5
                        )
                );


        side.setBackground(dark);


        String[] names = {

                "Register Pump",
                "Remove Pump",
                "View All Pumps",
                "Price List",
                "Rating Summary",
                "All Bookings",
                "All Feedback"
        };


        for (String name : names) {

            JButton b =
                    sideButton(name);

            side.add(b);


            if (name.equals("Register Pump")) {

                b.addActionListener(
                        e -> registerPump()
                );

            } else if (name.equals("Remove Pump")) {

                b.addActionListener(
                        e -> removePump()
                );

            } else if (name.equals("View All Pumps")) {

                b.addActionListener(
                        e -> showAllPumps()
                );

            } else if (name.equals("Price List")) {

                b.addActionListener(
                        e -> priceList()
                );

            } else if (name.equals("Rating Summary")) {

                b.addActionListener(
                        e -> ratingSummary()
                );

            } else if (name.equals("All Bookings")) {

                b.addActionListener(
                        e -> showBookings()
                );

            } else if (name.equals("All Feedback")) {

                b.addActionListener(
                        e -> allFeedback()
                );
            }
        }


        JButton back =
                sideButton("Back to Home");

        side.add(back);


        back.addActionListener(
                e -> cardLayout.show(
                        mainPanel,
                        "HOME"
                )
        );


        JLabel title =
                new JLabel("ADMIN DASHBOARD");


        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );


        panel.add(
                side,
                BorderLayout.WEST
        );

        panel.add(
                title,
                BorderLayout.NORTH
        );


        return panel;
    }


    // =====================================================
    // BUTTON DESIGN
    // =====================================================

    JButton button(String text) {

        JButton b =
                new JButton(text);

        b.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        b.setFocusPainted(false);

        return b;
    }


    JButton sideButton(String text) {

        JButton b =
                new JButton(text);

        b.setForeground(Color.WHITE);

        b.setBackground(blue);

        b.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        b.setFocusPainted(false);

        return b;
    }


    // =====================================================
    // TABLE
    // =====================================================

    void showTable(
            String title,
            String[] columns,
            Object[][] data) {


        JFrame frame =
                new JFrame(title);


        frame.setSize(
                950,
                450
        );


        frame.setLocationRelativeTo(this);


        DefaultTableModel model =
                new DefaultTableModel(
                        data,
                        columns
                );


        JTable table =
                new JTable(model);


        table.setRowHeight(28);


        JScrollPane scroll =
                new JScrollPane(table);


        frame.add(scroll);


        frame.setVisible(true);
    }


    // =====================================================
    // SELECT ZONE
    // =====================================================

    void selectZone() {

        String[] zones = {

                "Mirpur",
                "Gulshan",
                "Nabisco"
        };


        String zone =
                (String) JOptionPane.showInputDialog(

                        this,

                        "Select Zone:",

                        "Zone Selection",

                        JOptionPane.QUESTION_MESSAGE,

                        null,

                        zones,

                        zones[0]
                );


        if (zone == null)
            return;


        ArrayList<Object[]> rows =
                new ArrayList<>();


        for (Pump p :
                pumpManager.getPumps()) {


            if (p.getZone()
                    .equalsIgnoreCase(zone)) {


                rows.add(
                        new Object[]{

                                p.getName(),

                                p.getZone(),

                                p.isOpen()
                                        ? "OPEN"
                                        : "CLOSED",

                                p.getOil(),

                                p.getDiesel(),

                                p.getGas()
                        }
                );
            }
        }


        showTable(

                "Pumps in " + zone,

                new String[]{

                        "Pump",
                        "Zone",
                        "Status",
                        "Oil",
                        "Diesel",
                        "Gas"
                },

                rows.toArray(
                        new Object[0][]
                )
        );
    }


    // =====================================================
    // SEARCH PUMP
    // =====================================================

    void searchPump() {

        String name =
                JOptionPane.showInputDialog(
                        this,
                        "Enter pump name:"
                );


        if (name == null)
            return;


        for (Pump p :
                pumpManager.getPumps()) {


            if (p.getName()
                    .toLowerCase()
                    .contains(
                            name.toLowerCase()
                    )) {


                showPump(p);

                return;
            }
        }


        JOptionPane.showMessageDialog(
                this,
                "Pump not found!"
        );
    }


    // =====================================================
    // OPEN PUMPS
    // =====================================================

    void showOpenPumps() {

        ArrayList<Object[]> rows =
                new ArrayList<>();


        for (Pump p :
                pumpManager.getPumps()) {


            if (p.isOpen()) {

                rows.add(
                        new Object[]{

                                p.getName(),
                                p.getZone(),
                                p.getOil(),
                                p.getDiesel(),
                                p.getGas()
                        }
                );
            }
        }


        showTable(

                "Open Pumps",

                new String[]{

                        "Pump",
                        "Zone",
                        "Oil",
                        "Diesel",
                        "Gas"
                },

                rows.toArray(
                        new Object[0][]
                )
        );
    }


    // =====================================================
    // ALL PUMPS
    // =====================================================

    void showAllPumps() {

        ArrayList<Object[]> rows =
                new ArrayList<>();


        for (Pump p :
                pumpManager.getPumps()) {


            rows.add(
                    new Object[]{

                            p.getName(),
                            p.getZone(),

                            p.isOpen()
                                    ? "OPEN"
                                    : "CLOSED",

                            p.getOil(),
                            p.getDiesel(),
                            p.getGas(),
                            p.getSales()
                    }
            );
        }


        showTable(

                "All Pumps",

                new String[]{

                        "Pump",
                        "Zone",
                        "Status",
                        "Oil",
                        "Diesel",
                        "Gas",
                        "Sales"
                },

                rows.toArray(
                        new Object[0][]
                )
        );
    }


    // =====================================================
    // QUEUE STATUS
    // =====================================================

    void queueStatus() {

        String name =
                JOptionPane.showInputDialog(
                        this,
                        "Enter pump name:"
                );


        if (name == null)
            return;


        Pump p =
                pumpManager.findPump(name);


        if (p == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Pump not found!"
            );

            return;
        }


        int currentQueue =
                bookingManager.queueCount(p);


        String warning;


        if (currentQueue >=
                BookingManager.MAX_QUEUE) {

            warning =
                    "Queue is full!";

        } else if (currentQueue >= 10) {

            warning =
                    "Queue is getting long.";

        } else {

            warning =
                    "Queue is available.";
        }


        JOptionPane.showMessageDialog(

                this,

                "PUMP QUEUE STATUS\n\n" +

                        "Pump Name: "
                        + p.getName() + "\n" +

                        "Current Vehicles: "
                        + currentQueue + "\n" +

                        "Available Queue Space: "
                        + (
                        BookingManager.MAX_QUEUE
                                - currentQueue
                ) + "\n" +

                        "Maximum Queue: "
                        + BookingManager.MAX_QUEUE
                        + "\n\n" +

                        warning
        );
    }


    // =====================================================
    // BOOK FUEL
    // =====================================================

    void bookFuel() {

        JTextField vehicle =
                new JTextField();


        JTextField pump =
                new JTextField();


        String[] fuels = {

                "Oil",
                "Diesel",
                "Gas"
        };


        JComboBox<String> fuel =
                new JComboBox<>(fuels);


        JPanel panel =
                new JPanel(
                        new GridLayout(
                                3, 2, 5, 5
                        )
                );


        panel.add(
                new JLabel(
                        "Vehicle Number:"
                )
        );

        panel.add(vehicle);


        panel.add(
                new JLabel(
                        "Fuel Type:"
                )
        );

        panel.add(fuel);


        panel.add(
                new JLabel(
                        "Pump Name:"
                )
        );

        panel.add(pump);


        int result =
                JOptionPane.showConfirmDialog(

                        this,

                        panel,

                        "Book Fuel",

                        JOptionPane.OK_CANCEL_OPTION
                );


        if (result !=
                JOptionPane.OK_OPTION)

            return;


        if (vehicle.getText()
                .trim()
                .isEmpty()
                ||
                pump.getText()
                        .trim()
                        .isEmpty()) {


            JOptionPane.showMessageDialog(

                    this,

                    "Please fill up all information!"
            );

            return;
        }


        Pump p =
                pumpManager.findPump(
                        pump.getText()
                );


        if (p == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Pump not found!"
            );

            return;
        }


        if (!p.isOpen()) {

            JOptionPane.showMessageDialog(

                    this,

                    "This pump is currently closed!"
            );

            return;
        }


        int currentQueue =
                bookingManager.queueCount(p);


        if (currentQueue >=
                BookingManager.MAX_QUEUE) {


            JOptionPane.showMessageDialog(

                    this,

                    "WARNING!\n\n" +

                            "Queue is full.\n" +

                            "Please select another pump."
            );

            return;
        }


        boolean success =
                bookingManager.bookFuel(

                        vehicle.getText(),

                        fuel.getSelectedItem()
                                .toString(),

                        p
                );


        if (success) {

            int queueNumber =
                    currentQueue + 1;


            int minute =
                    20 + currentQueue * 10;


            String time =
                    "5:" +
                            String.format(
                                    "%02d",
                                    minute
                            );


            JOptionPane.showMessageDialog(

                    this,

                    "BOOKING SUCCESSFUL!\n\n" +

                            "Pump: "
                            + p.getName() + "\n" +

                            "Vehicle: "
                            + vehicle.getText() + "\n" +

                            "Fuel: "
                            + fuel.getSelectedItem() + "\n" +

                            "Queue Number: "
                            + queueNumber + "\n" +

                            "Estimated Time: "
                            + time
            );
        }
    }


    // =====================================================
    // SHOW BOOKINGS
    // =====================================================

    void showBookings() {

        if (bookingManager
                .getBookings()
                .size() == 0) {


            JOptionPane.showMessageDialog(
                    this,
                    "No bookings available."
            );

            return;
        }


        ArrayList<Object[]> rows =
                new ArrayList<>();


        for (Vehicle v :
                bookingManager.getBookings()) {


            rows.add(
                    new Object[]{

                            v.number,
                            v.fuel,
                            v.pump,
                            v.queueNumber,
                            v.time
                    }
            );
        }


        showTable(

                "All Bookings",

                new String[]{

                        "Vehicle",
                        "Fuel",
                        "Pump",
                        "Queue Number",
                        "Estimated Time"
                },

                rows.toArray(
                        new Object[0][]
                )
        );
    }


    // =====================================================
    // CANCEL BOOKING
    // =====================================================

    void cancelBooking() {

        String number =
                JOptionPane.showInputDialog(

                        this,

                        "Enter vehicle number:"
                );


        if (number == null)
            return;


        boolean result =
                bookingManager.cancelBooking(
                        number
                );


        if (result) {

            JOptionPane.showMessageDialog(

                    this,

                    "Booking cancelled successfully."
            );

        } else {

            JOptionPane.showMessageDialog(

                    this,

                    "Booking not found."
            );
        }
    }


    // =====================================================
    // NEAREST PUMP
    // =====================================================

    void nearestPump() {

        String[] zones = {

                "Mirpur",
                "Gulshan",
                "Nabisco"
        };


        String zone =
                (String) JOptionPane.showInputDialog(

                        this,

                        "Select your area:",

                        "Nearest Pump",

                        JOptionPane.QUESTION_MESSAGE,

                        null,

                        zones,

                        zones[0]
                );


        if (zone == null)
            return;


        for (Pump p :
                pumpManager.getPumps()) {


            if (p.getZone()
                    .equalsIgnoreCase(zone)
                    &&
                    p.isOpen()) {


                JOptionPane.showMessageDialog(

                        this,

                        "Nearest Suggested Pump:\n\n"
                                + p.getName()
                );

                return;
            }
        }


        JOptionPane.showMessageDialog(

                this,

                "No open pump found."
        );
    }


    // =====================================================
    // SALES HISTORY
    // =====================================================

    void salesHistory() {

        ArrayList<Object[]> rows =
                new ArrayList<>();


        ArrayList<Pump> list =
                pumpManager.getPumps();


        int start =
                Math.max(
                        0,
                        list.size() - 5
                );


        for (int i = start;
             i < list.size();
             i++) {


            Pump p = list.get(i);


            rows.add(
                    new Object[]{

                            p.getName(),

                            p.getSales(),

                            p.getSales() > 5000
                                    ? "Good Sales"
                                    : "Normal Sales"
                    }
            );
        }


        showTable(

                "Last 5 Sales History",

                new String[]{

                        "Pump",
                        "Sales",
                        "Status"
                },

                rows.toArray(
                        new Object[0][]
                )
        );
    }


    // =====================================================
    // RATE SERVICE
    // =====================================================

    void rateService() {

        String pump =
                JOptionPane.showInputDialog(

                        this,

                        "Enter pump name:"
                );


        if (pump == null)
            return;


        Pump p =
                pumpManager.findPump(pump);


        if (p == null) {

            JOptionPane.showMessageDialog(

                    this,

                    "Pump not found!"
            );

            return;
        }


        String[] ratings = {

                "1",
                "2",
                "3",
                "4",
                "5"
        };


        String r =
                (String) JOptionPane.showInputDialog(

                        this,

                        "Give Rating:",

                        "Rating",

                        JOptionPane.QUESTION_MESSAGE,

                        null,

                        ratings,

                        ratings[4]
                );


        if (r == null)
            return;


        int rating =
                Integer.parseInt(r);


        String message;


        if (rating <= 2) {

            message =
                    JOptionPane.showInputDialog(

                            this,

                            "What happened?"
                    );


            if (message == null)
                message = "";

        } else {

            message =
                    "Good service.";
        }


        feedbacks.add(

                new Feedback(

                        p.getName(),
                        rating,
                        message
                )
        );


        JOptionPane.showMessageDialog(

                this,

                "Thank you for your feedback!"
        );
    }


    // =====================================================
    // REGISTER PUMP
    // =====================================================

    void registerPump() {

        JTextField name =
                new JTextField();

        JTextField zone =
                new JTextField();

        JTextField oil =
                new JTextField();

        JTextField diesel =
                new JTextField();

        JTextField gas =
                new JTextField();

        JTextField sales =
                new JTextField();


        JPanel panel =
                new JPanel(
                        new GridLayout(
                                6, 2, 5, 5
                        )
                );


        panel.add(
                new JLabel("Pump Name:")
        );

        panel.add(name);


        panel.add(
                new JLabel("Zone:")
        );

        panel.add(zone);


        panel.add(
                new JLabel("Oil Stock:")
        );

        panel.add(oil);


        panel.add(
                new JLabel("Diesel Stock:")
        );

        panel.add(diesel);


        panel.add(
                new JLabel("Gas Stock:")
        );

        panel.add(gas);


        panel.add(
                new JLabel("Total Sales:")
        );

        panel.add(sales);


        int result =
                JOptionPane.showConfirmDialog(

                        this,

                        panel,

                        "Register New Pump",

                        JOptionPane.OK_CANCEL_OPTION
                );


        if (result !=
                JOptionPane.OK_OPTION)

            return;


        try {

            pumpManager.addPump(

                    name.getText(),

                    zone.getText(),

                    Integer.parseInt(
                            oil.getText()
                    ),

                    Integer.parseInt(
                            diesel.getText()
                    ),

                    Integer.parseInt(
                            gas.getText()
                    ),

                    Integer.parseInt(
                            sales.getText()
                    )
            );


            JOptionPane.showMessageDialog(

                    this,

                    "New pump registered successfully."
            );


        } catch (Exception e) {

            JOptionPane.showMessageDialog(

                    this,

                    "Please enter valid information."
            );
        }
    }


    // =====================================================
    // REMOVE PUMP
    // =====================================================

    void removePump() {

        String name =
                JOptionPane.showInputDialog(

                        this,

                        "Enter pump name to remove:"
                );


        if (name == null)
            return;


        boolean result =
                pumpManager.removePump(name);


        if (result) {

            JOptionPane.showMessageDialog(

                    this,

                    "Pump removed successfully."
            );

        } else {

            JOptionPane.showMessageDialog(

                    this,

                    "Pump not found!"
            );
        }
    }


    // =====================================================
    // PRICE LIST
    // =====================================================

    void priceList() {

        JOptionPane.showMessageDialog(

                this,

                "CURRENT FUEL PRICE LIST\n\n" +

                        "Oil/Petrol : 130 Tk/L\n" +

                        "Diesel : 110 Tk/L\n" +

                        "Gas : 65 Tk/L",

                "Price List",

                JOptionPane.INFORMATION_MESSAGE
        );
    }


    // =====================================================
    // RATING SUMMARY
    // =====================================================

    void ratingSummary() {

        if (feedbacks.size() == 0) {

            JOptionPane.showMessageDialog(

                    this,

                    "No rating available."
            );

            return;
        }


        ArrayList<Object[]> rows =
                new ArrayList<>();


        for (Feedback f : feedbacks) {

            rows.add(
                    new Object[]{

                            f.pump,

                            f.rating + "/5",

                            f.message
                    }
            );
        }


        showTable(

                "Rating Summary",

                new String[]{

                        "Pump",
                        "Rating",
                        "Feedback"
                },

                rows.toArray(
                        new Object[0][]
                )
        );
    }


    // =====================================================
    // ALL FEEDBACK
    // =====================================================

    void allFeedback() {

        if (feedbacks.size() == 0) {

            JOptionPane.showMessageDialog(

                    this,

                    "No feedback available."
            );

            return;
        }


        ArrayList<Object[]> rows =
                new ArrayList<>();


        for (Feedback f : feedbacks) {

            rows.add(
                    new Object[]{

                            f.pump,
                            f.rating + "/5",
                            f.message
                    }
            );
        }


        showTable(

                "All User Feedback",

                new String[]{

                        "Pump Name",
                        "Rating",
                        "User Feedback"
                },

                rows.toArray(
                        new Object[0][]
                )
        );
    }


    // =====================================================
    // SHOW ONE PUMP
    // =====================================================

    void showPump(Pump p) {

        JOptionPane.showMessageDialog(

                this,

                "Pump Name: "
                        + p.getName() +

                        "\nZone: "
                        + p.getZone() +

                        "\nStatus: "
                        + (
                        p.isOpen()
                                ? "OPEN"
                                : "CLOSED"
                ) +

                        "\nOil: "
                        + p.getOil() + " L" +

                        "\nDiesel: "
                        + p.getDiesel() + " L" +

                        "\nGas: "
                        + p.getGas() + " L" +

                        "\nSales: "
                        + p.getSales() + " Tk",

                "Pump Details",

                JOptionPane.INFORMATION_MESSAGE
        );
    }


    // =====================================================
    // ABOUT PROJECT
    // =====================================================

    void aboutProject() {

        JOptionPane.showMessageDialog(

                this,

                "SMART FUEL PUMP MANAGEMENT SYSTEM\n\n" +

                        "This Java Swing project manages fuel pumps.\n\n" +

                        "OOP CONCEPTS USED:\n\n" +

                        "1. Encapsulation\n" +

                        "2. Abstraction\n" +

                        "3. Inheritance\n" +

                        "4. Polymorphism\n\n" +

                        "Other concepts:\n" +

                        "Class, Object, Constructor,\n" +

                        "ArrayList, Methods, final and Swing GUI.",

                "About Project",

                JOptionPane.INFORMATION_MESSAGE
        );
    }
}
