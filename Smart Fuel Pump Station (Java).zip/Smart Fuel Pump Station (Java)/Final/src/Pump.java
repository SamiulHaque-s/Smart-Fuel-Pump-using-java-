// ================= PUMP CLASS =================
// Pump, FuelStation-এর child class।

class Pump extends FuelStation {

    // ================= ENCAPSULATION =================
    // Data private রাখা হয়েছে।
    // বাইরের class সরাসরি এগুলো পরিবর্তন করতে পারবে না।

    private String name;
    private String zone;
    private boolean open;
    private int oil;
    private int diesel;
    private int gas;
    private int sales;


    // ================= CONSTRUCTOR =================
    // Object তৈরি করার সময় information নেওয়ার জন্য constructor।

    Pump(String name, String zone, boolean open,
         int oil, int diesel, int gas, int sales) {

        this.name = name;
        this.zone = zone;
        this.open = open;
        this.oil = oil;
        this.diesel = diesel;
        this.gas = gas;
        this.sales = sales;
    }


    // ================= GETTERS =================
    // private data বাইরে থেকে দেখার জন্য getter ব্যবহার করছি।

    public String getName() {
        return name;
    }

    public String getZone() {
        return zone;
    }

    public boolean isOpen() {
        return open;
    }

    public int getOil() {
        return oil;
    }

    public int getDiesel() {
        return diesel;
    }

    public int getGas() {
        return gas;
    }

    public int getSales() {
        return sales;
    }


    // ================= POLYMORPHISM =================
    // Parent class FuelStation-এ showInfo() ছিল।
    // এখানে child class Pump নিজের version দিয়েছে।

    @Override
    void showInfo() {
        System.out.println("Pump Name: " + name);
    }
}
