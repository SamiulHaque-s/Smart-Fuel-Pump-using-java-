import java.util.ArrayList;


// ================= PUMP MANAGER =================
// Pump add, remove, search এবং default pump-এর কাজ এখানে।

class PumpManager {

    ArrayList<Pump> pumps = new ArrayList<>();


    // ================= CONSTRUCTOR =================

    PumpManager() {

        addDefaultPumps();
    }


    // ================= DEFAULT PUMPS =================

    void addDefaultPumps() {

        pumps.add(new Pump(
                "Mirpur Padma Pump",
                "Mirpur",
                true,
                5000,
                4000,
                3000,
                7000
        ));

        pumps.add(new Pump(
                "Mirpur Meghna Pump",
                "Mirpur",
                true,
                4500,
                3500,
                2500,
                4500
        ));

        pumps.add(new Pump(
                "Gulshan Padma Pump",
                "Gulshan",
                true,
                6000,
                5000,
                3500,
                9000
        ));

        pumps.add(new Pump(
                "Gulshan Meghna Pump",
                "Gulshan",
                true,
                4000,
                3000,
                2000,
                3000
        ));

        pumps.add(new Pump(
                "Nabisco Padma Pump",
                "Nabisco",
                false,
                3000,
                2500,
                1500,
                6000
        ));

        pumps.add(new Pump(
                "Nabisco Meghna Pump",
                "Nabisco",
                true,
                3500,
                3000,
                2000,
                5500
        ));
    }


    // ================= ADD PUMP =================

    void addPump(String name, String zone,
                 int oil, int diesel,
                 int gas, int sales) {

        pumps.add(new Pump(
                name,
                zone,
                true,
                oil,
                diesel,
                gas,
                sales
        ));
    }


    // ================= REMOVE PUMP =================

    boolean removePump(String name) {

        Pump p = findPump(name);

        if (p != null) {

            pumps.remove(p);

            return true;
        }

        return false;
    }


    // ================= FIND PUMP =================

    Pump findPump(String name) {

        if (name == null)
            return null;

        for (Pump p : pumps) {

            if (p.getName().equalsIgnoreCase(name)) {

                return p;
            }
        }

        return null;
    }


    // ================= GET ALL PUMPS =================

    ArrayList<Pump> getPumps() {

        return pumps;
    }
}
