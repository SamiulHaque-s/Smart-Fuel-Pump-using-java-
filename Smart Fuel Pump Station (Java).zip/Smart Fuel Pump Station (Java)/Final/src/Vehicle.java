// ================= VEHICLE CLASS =================

class Vehicle {

    String number;
    String fuel;
    String pump;
    String time;
    int queueNumber;


    // ================= CONSTRUCTOR =================

    Vehicle(String number, String fuel, String pump,
            String time, int queueNumber) {

        this.number = number;
        this.fuel = fuel;
        this.pump = pump;
        this.time = time;
        this.queueNumber = queueNumber;
    }
}
