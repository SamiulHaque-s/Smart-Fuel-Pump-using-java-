import javax.swing.SwingUtilities;

// ================= MAIN CLASS =================

public class main {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {

                GUI app = new GUI();
                app.setVisible(true);
            }
        });
    }
}
